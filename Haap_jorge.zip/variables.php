<?php
// guardar valores y hacer operaciones
const NOMBRE_PERSONAL = array ('HAAP', 'PEREZ','LOPEZ', 'GOMEZ','AEDO');
const NACIMIENTO = array ('24/11/1971', '12/03/1999','04/01/2001','18/04/1966','11/02/2000');
const PUESTO = array ('docente', 'secretario','bibliotecario','bibliotecario','docente');
const ANTIGUEDAD = array (10,8,12,10,8);
const HORAS = array (9,11,0,0,9);
$valor_hora=1200;
$legajo= array ("1"=> "HAAP", "2"=> "PEREZ","3"=> "LOPEZ","4"=> "GOMEZ","5"=> "AEDO" );