<?php
$conexion=mysqli_connect ("localhost", "id18198511_root", "CR\m3~_*>b}_ejLw", "id18198511_ni_utn");
?>